﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Queue<Person> people = new Queue<Person>();
            List<string>lines=new List<string>();
            if (File.Exists("people.txt"))
            {
                lines = File.ReadAllLines("people.txt").ToList();
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split(' ');
                        Person person = new Person
                        {
                            familia = parts[0],
                            Name = parts[1],
                            Otchestvo = parts[2],
                            Age = int.Parse(parts[3]),
                            Weight = int.Parse(parts[4])
                        };
                        people.Enqueue(person);
                        listBox2.Items.Add($"ФИО: {person.familia} {person.Name} {person.Otchestvo}, Возраст: {person.Age}, вес: {person.Weight}");
                    }
                    var Under40 = from person in people
                                        where person.Age < 40
                                        select person;
                    foreach (var person in Under40)
                    {

                        listBox1.Items.Add($"ФИО: {person.familia} {person.Name} {person.Otchestvo}, Возраст: {person.Age}, вес: {person.Weight}");

                    }
            }
            else { MessageBox.Show("Файл не найден"); }
            
        }

        
    }
}
