﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace пр_14_оа
{
    public partial class Form1 : Form
    {
        Stack<int> stack =new Stack<int>();
        Queue<int> queue = new Queue<int>();
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            stack.Clear();
            if (textBox1.Text!="")
            {
                int n=Convert.ToInt32(textBox1.Text);
                if (n > 0)
                {
                    for (int i = 01; i <= n; i++)
                    {
                        stack.Push(i);
                    }
                    label1.Text = $"Размерность стека {stack.Count}";
                    label2.Text = $"Верхний элемент стека {stack.Peek()}";
                    label3.Text = $"Содержимое стека {string.Join(" ", stack)}";
                }
                else 
                {
                    MessageBox.Show("Число не может быть отрицатльным");
                }
            }
            else
            {
                MessageBox.Show("Вы ввели что то не то");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                int n = int.Parse(textBox2.Text);
                if (n > 0)
                {
                    for (int i = 1; i <= n; i++)
                    {
                        queue.Enqueue(i);
                    }
                    label7.Text = $"Содержимое стека {string.Join(" ", queue)}";
                }
                else
                {
                    MessageBox.Show("Число не может быть отрицатльным");
                }
            }
            else
            {
                MessageBox.Show("Вы ввели что то не то");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool a = true;
            int pra1 = 0;
            int pra2 = 0;
            Stack<char> sk = new Stack<char>();
            try
            {
                if (textBox1.Text != "")
                {
                    string s = textBox1.Text;
                    for (int i = 0; i < s.Length; i++)
                    {
                        sk.Push(s[i]);
                        char c = s[i];
                        if (sk.Peek() != '0' && sk.Peek() != '1' && sk.Peek() != '2' && sk.Peek() != '3' && sk.Peek() != '4' && sk.Peek() != '5' && sk.Peek() != '6' && sk.Peek() != '7' && sk.Peek() != '8' && Il.Peek() != '9' && Il.Peek() != '/' && Il.Peek() != '*' && Il.Peek() != '-' && Il.Peek() != '+' && Il.Peek() != '.' && Il.Peek() != '(' && Il.Peek() != ')')
                            a = false;
                        if ((sk.Peek() == '(')) { pra1++; }
                        if (sk.Peek() == ')') { pra2++; }
                    }
                    if (a == true && pra1 == pra2)
                    {
                       label6.Text="Скобки сбалансированые";
                        StreamWriter kk = File.CreateText("t.txt");
                        kk.WriteLine(s);
                        kk.Close();
                    }
                    else if (pra1 > pra2)
                    {
                        label6.Text=" лишняя  на позиции" + s.IndexOf("(");
                    }
                    else if (pra1 < pra2)
                    {
                        label6.Text=" лишняя на позиции" + s.IndexOf(")");
                    }
                }

            }
    }
}
